create table  bookinfo (bid int NOT NULL AUTO_INCREMENT, author varchar(20) NOT NULL , 
name varchar(20) NOT NULL , price int NOT NULL  , PRIMARY KEY (bid)
);