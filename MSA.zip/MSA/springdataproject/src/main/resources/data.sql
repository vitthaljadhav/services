insert into bookinfo values (101,'Gausling','Java',9000);
insert into bookinfo values (102,'Andy','Dbms',7000);
insert into bookinfo values (103,'Amit','C',6000);
insert into bookinfo values (104,'Ravi','C',7000);
insert into bookinfo values (105,'Manik','java',7000);
insert into bookinfo values (106,'Mohit','java',7000);
insert into bookinfo values (107,'Amit','Spring',6000);
commit;