insert into userinfo values (101,'Adam@Gmail.com','Adam');
insert into userinfo values (102,'Eve@Gmail.com','Eve');
insert into userinfo values (103,'Jack@Gmail.com','Jack');
commit;